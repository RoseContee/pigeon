// const domain = 'http://localhost:10000';
const domain = 'https://joinpigeon.com';

const REDIRECT_URL = 'https://adlljmlbangmeenndganepfkilcdihnm.chromiumapp.org/';

const GOOGLE_CLIENT_ID = '97803995479-0epuvc2735gllpi9hnp1k3pocb0le73t.apps.googleusercontent.com';
const GOOGLE_CLIENT_SECRET = '6tkBTQUnoNx4V9GeJfp2cBxy';

const ZOOM_CLIENT_ID = 'XqfPyy7RyKcT8YxbkBjsw';
const ZOOM_CLIENT_SECRET = 'ovAB1fOHFXjFvoIheVkGdjNN4490Imr6';