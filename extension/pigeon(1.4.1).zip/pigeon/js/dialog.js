var selected_value, limitation, user, delay = 0;
var zoom_access_token, zoom_link, zoom_password;
chrome.runtime.sendMessage({
    method: 'get_selected_value',
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.method == 'selected_value') {
        selected_value = request.value;
    }
});

$(function () {
    $.ajax({
        method: 'GET',
        url: `${domain}/api/apps`,
        success(data) {
            data.forEach(function(app) {
                $('#apps').append(getAppTemplate(app));
            });

            $('.apps').on('change', function(e) {
                var app = $(this).parent().data('name');
                $('#app-selected').text('(' + app + ' selected)');
                if (e.target.value == 2 && !zoom_access_token) {
                    zoomLogin();
                }
            });

            zoom_access_token = zoom_link = null;
        },
        error(data) {
            $('#app-error').text(data.responseText);
            errorHandle();
        }
    });

    $('#event-date').val(new Date().toISOString());
    $('#selected-date').text(new Date().toGMTString());

    $('#datetimepicker').datetimepicker({
        inline: true,
        sideBySide: true,
        minDate: new Date(),
    });
});

function setData(data) {
    user = data.result.user;
    $('#guest-email').autocomplete({
        source: user.guests,
    });
    if (user.email) {
        userEmail = user.email;
    }
    if (selected_value.value && selected_value.value.includes('@')) {
        $('#guest-email').val(selected_value.value);
        $('#add-guest').click();
    }
    var email;
    selected_value.selected_links.forEach(function (href) {
        email = selected_value.links[href];
        if (email) {
            $('#guest-email').val(email);
            $('#add-guest').click();
        }
    });
    limitation = data.result.current;
    if (limitation == 0) {
        $('#home-error').show();
        return;
    }
}

function errorHandle(hide_error, instant) {
    if (!hide_error) $('#main-error').text('Cannot send invite at this time');
    setTimeout(function() {
        chrome.runtime.sendMessage({
            method: 'close_popup',
        });
    }, instant ? 0 : 1000);
}

function getAppTemplate(app) {
    return `<div class="col-6 btn-group-toggle mt-1">
                <label class="btn p-1 text-center" data-name="${app.name}">
                    <img src="${app.image}" class="app-image">
                    <input type="radio" name="app" class="apps" value="${app.id}">
                </label>
            </div>`;
}

function guestTemplate(email) {
    return `<div class="col-12 input-group mb-1">
                <div class="form-control pl-2 p-0 border-0">${email}</div>
                <div class="input-group-append">
                <button class="btn btn-outline-danger img-circle p-1 remove-guest"><i class="fa fa-minus"></i></button>
                </div>
            </div>`;
}

function requestId(length) {
    var result           = '';
    var characters       = 'abcdefghijklmnopqrstuvwxyz0123456789';
    var charactersLength = characters.length;
    for ( var i = 0; i < length; i++ ) {
       result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
}

function get_google_oauth_url(state) {
    return `https://accounts.google.com/o/oauth2/v2/auth?client_id=${encodeURIComponent(GOOGLE_CLIENT_ID)}
&response_type=code
&redirect_uri=${encodeURIComponent(REDIRECT_URL)}
&state=${encodeURIComponent(state)}
&scope=${encodeURIComponent('openid profile email https://www.googleapis.com/auth/calendar')}
&prompt=consent
&nonce=${encodeURIComponent(Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15))}
&access_type=offline`;
}

function get_zoom_oath_url(state) {
    return `https://zoom.us/oauth/authorize?response_type=code
&client_id=${encodeURIComponent(ZOOM_CLIENT_ID)}
&redirect_uri=${encodeURIComponent(REDIRECT_URL)}
&state=${encodeURIComponent(state)}`;
}

function zoomLogin() {
    $('#loading').show();
    const token = requestId(15);
    chrome.identity.launchWebAuthFlow({
        url: get_zoom_oath_url(token),
        interactive: true,
    }, function(redirect_url) {
        if (chrome.runtime.lastError) {
            $('#app-error').text(chrome.runtime.lastError.message);
            $('#loading').hide();
            return;
        }
        redirect_url = new URL(redirect_url);
        if (token != redirect_url.searchParams.get('state')) {
            $('#app-error').text('Invalid state parameter');
            $('#loading').hide();
            return;
        }
        const code = redirect_url.searchParams.get('code');
        $.ajax({
            method: 'POST',
            url: 'https://zoom.us/oauth/token',
            headers: {
                'Authorization': 'Basic ' + btoa(ZOOM_CLIENT_ID + ':' + ZOOM_CLIENT_SECRET),
            },
            data: {
                code: code,
                redirect_uri: REDIRECT_URL,
                grant_type: 'authorization_code',
            },
            success(data) {
                zoom_access_token = data.access_token;
                $('#loading').hide();
            },
            error(data) {
                $('#app-error').text(data.responseText);
                errorHandle();
            }
        });
    });
}

function getZoomLink(data) {
    zoom_password = requestId(6);
    $.ajax({
        async: false,
        method: 'POST',
        url: `${domain}/api/create-zoom-link`,
        data: {
            access_token: zoom_access_token,
            topic: data.event_name,
            start_time: data.event_date,
            password: zoom_password,
        },
        success(data) {
            if (data.zoom_link) {
                zoom_link = data.zoom_link;
            }
        }
    })
}

function createEvent(request) {
    $('#loading').show();
    $.ajax({
        method: 'POST',
        url: `${domain}/api/get-user-info`,
        data: {
            email: userEmail,
            access_token: authToken,
        },
        success(data) {
            if (data.status == 200) {
                if (!data.result.current || data.result.current == 0) {
                    $('#home-error').show();
                    $('#main-error').html($('#home-error').html());
                    $('#loading').hide();
                    return;
                }
                $.ajax({
                    method: 'GET',
                    url: 'https://www.googleapis.com/calendar/v3/users/me/calendarList',
                    headers: {
                        'Authorization': 'Bearer ' + authToken
                    },
                    success(data) {
                        data.items.forEach(function(item) {
                            if (item.id == userEmail) {
                                var tz = Intl.DateTimeFormat().resolvedOptions().timeZone, attendees = [];
                                request.guests.forEach(function(email) {
                                    attendees.push({'email': email});
                                });
                                if (request.app == 2) {
                                    getZoomLink(request);
                                    if (!zoom_link) {
                                        $('#loading').hide();
                                        errorHandle();
                                        return;
                                    }
                                }
                                var event_data = {
                                    'summary': request.event_name,
                                    'description': `Hi,<br><br>${user.name} is inviting you to attend ${request.event_name} via Pigeon.
${(request.app == 2 ? `<br><br>Here is the link to join the meeting - <a href="${zoom_link}">${zoom_link}</a> (passcode: ${zoom_password})` : '')}
<br><br>Pigeon Chrome Extension helps you book video meeting on Google Meet & Zoom directly from LinkedIn chat. Stop sending meeting details on emails.
<br>Start booking meeting on LinkedIn today! <a href="https://chrome.google.com/webstore/detail/pigeon/adlljmlbangmeenndganepfkilcdihnm">Install Pigeon</a>
<br><br>See you!<br>Pigeon Support`,
                                    'start': {
                                        'dateTime': request.event_date
                                    },
                                    'end': {
                                        'dateTime': request.event_date
                                    },
                                    'attendees': attendees,
                                    'reminders': {
                                        'useDefault': false,
                                        'overrides': [
                                            {'method': 'email', 'minutes': 30}
                                        ]
                                    },
                                };
                                if (request.app == 1) {
                                    event_data.conferenceData = {
                                        'createRequest': {
                                            'requestId' : requestId(15),
                                            'conferenceSolutionKey': {
                                                'type': 'hangoutsMeet'
                                            }
                                        }
                                    };
                                } else if (request.app == 2) {
                                    event_data.conferenceData = {
                                        'entryPoints': [{
                                            'entryPointType': 'more',
                                            'uri': zoom_link
                                        }],
                                        'conferenceSolution': {
                                            'key': {
                                                'type': 'hangoutsMeet'
                                            }
                                        }
                                    };
                                }
                                $.ajax({
                                    method: 'POST',
                                    url: 'https://www.googleapis.com/calendar/v3/calendars/'+item.id+'/events?sendUpdates=all&conferenceDataVersion=1',
                                    headers: {
                                        'Authorization': 'Bearer ' + authToken,
                                    },
                                    dataType : 'json',
                                    data: JSON.stringify(event_data),
                                    success(data) {
                                        if (data.status == 'confirmed') {
                                            $.ajax({
                                                method: 'POST',
                                                url: `${domain}/api/create-event`,
                                                data: {
                                                    token: authToken,
                                                    app: request.app,
                                                    attr: request.attr,
                                                    event_name: request.event_name,
                                                    host_name: item.id,
                                                    guests: request.guests,
                                                    event_date: moment(request.event_date).format("YYYY-MM-DDTHH:mm:ss"),
                                                    timezone: tz,
                                                },
                                                success(data) {
                                                    $('#loading').hide();
                                                    if (data.status == 200) {
                                                        $('#successModal').modal('show');
                                                    } else if (data.status == 403) {
                                                        for (key in data.message) {
                                                            $('#' + key + '-error').text(data.message[key]);
                                                        }
                                                    } else {
                                                        logout();
                                                    }
                                                },
                                                error(data) {
                                                    errorHandle();
                                                }
                                            });
                                        }
                                    },
                                    error(data) {
                                        errorHandle();
                                    }
                                });
                                return;
                            }
                        });
                    },
                    error(data) {
                        errorHandle();
                    }
                });            
            } else {
                logout();
            }
        },
        error(data) {
            errorHandle();
        }
    });
}