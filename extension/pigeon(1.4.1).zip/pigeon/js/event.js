var authToken = undefined, userEmail = undefined;
$(function() {
    chrome.storage.local.get('pigeon', function (item) {
        if (item.pigeon && item.pigeon.google_refresh_token) {
            $.ajax({
                method: 'POST',
                url: 'https://oauth2.googleapis.com/token',
                data: {
                    client_id: GOOGLE_CLIENT_ID,
                    client_secret: GOOGLE_CLIENT_SECRET,
                    refresh_token: item.pigeon.google_refresh_token,
                    grant_type: 'refresh_token',
                },
                success(data) {
                    authToken = data.access_token;
                    $.ajax({
                        method: 'GET',
                        url: 'https://www.googleapis.com/oauth2/v1/userinfo',
                        data: {
                            access_token: authToken,
                        },
                        success(data) {
                            $.ajax({
                                method: 'POST',
                                url: `${domain}/api/get-user-info`,
                                data: {
                                    email: data.email,
                                    access_token: authToken,
                                },
                                success(data) {
                                    if (data.status == 200) {
                                        setData(data);
                                        setTimeout(gotoPage, delay, 'home');
                                    } else {
                                        logout();
                                    }
                                },
                                error(data) {
                                    errorHandle();
                                }
                            });
                        },
                        error(data) {
                            logout();
                        }
                    });
                },
                error(data) {
                    logout();
                }
            });
        } else {
            setTimeout(gotoPage, delay, 'login');
        }
    });

    $('input').on('keypress, change', function() {
        $('.errors').text('');
    });

    $('#google-login').on('click', function() {
        $('#loading').show();
        $.ajax({
            method: 'GET',
            url: `${domain}/api/get-token`,
            success(data) {
                if (data.status == 200) {
                    const token = data.result;
                    chrome.identity.launchWebAuthFlow({
                        url: get_google_oauth_url(token),
                        interactive: true,
                    }, function(redirect_url) {
                        if (chrome.runtime.lastError) {
                            $('#error').text(chrome.runtime.lastError.message);
                            $('#loading').hide();
                            return;
                        }
                        redirect_url = new URL(redirect_url);
                        if (token != redirect_url.searchParams.get('state')) {
                            $('#error').text('Invalid state parameter');
                            $('#loading').hide();
                            return;
                        }
                        const code = redirect_url.searchParams.get('code');
                        $.ajax({
                            method: 'POST',
                            url: 'https://oauth2.googleapis.com/token',
                            data: {
                                code: code,
                                client_id: GOOGLE_CLIENT_ID,
                                client_secret: GOOGLE_CLIENT_SECRET,
                                redirect_uri: REDIRECT_URL,
                                grant_type: 'authorization_code',
                            },
                            success(data) {
                                const refresh_token = data.refresh_token;
                                authToken = data.access_token;
                                $.ajax({
                                    method: 'GET',
                                    url: 'https://oauth2.googleapis.com/tokeninfo',
                                    data: {
                                        id_token: data.id_token,
                                    },
                                    success(data) {
                                        $.ajax({
                                            method: 'POST',
                                            url: `${domain}/api/auth-google`,
                                            data: {
                                                token: token,
                                                access_token: authToken,
                                                email: data.email,
                                                name: data.name,
                                                avatar: data.picture,
                                                google_id: data.sub,
                                            },
                                            success(data) {
                                                if (data.status == 200) {
                                                    setData(data);
                                                    gotoPage('home');
                                                    chrome.storage.local.get('pigeon', function(item) {
                                                        if (!item.pigeon) item.pigeon = {};
                                                        item.pigeon.google_refresh_token = refresh_token;
                                                        chrome.storage.local.set({'pigeon': item.pigeon});
                                                    });
                                                } else {
                                                    $('#error').text(data.result.error);
                                                    $('#loading').hide();
                                                }
                                            },
                                            error(data) {
                                                errorHandle();
                                            }
                                        });
                                    },
                                    error(data) {
                                        errorHandle();
                                    }
                                });
                            },
                            error(data) {
                                errorHandle();
                            }
                        })
                    });
                }
            },
            error(data) {
                errorHandle();
            }
        });
    });
    
    $('#logout').on('click', logout);

    $('#goHome').on('click', function() {
        chrome.runtime.sendMessage({
            method: 'goto_page',
            page: '/',
        });
    });

    $('#guest-email').on('keypress', function(e) {
        if (e.keyCode == 13) {
            $('#add-guest').click();
        }
    });

    $('#add-guest').on('click', function() {
        var guest = $('#guest-email').val().trim().toLowerCase();
        if (guest == '') return;
        var mailFormat = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
        if (!guest.match(mailFormat)) {
            $('#guest-email-error').text('please input valid email');
            return;
        }
        var exist = false;
        $('#guest-list .form-control').each(function() {
            if ($(this).text().trim().toLowerCase() == guest) exist = true;
        });
        if (!exist) {
            $('#guest-list').append(guestTemplate(guest));
            $('.remove-guest').off('click').on('click', function() {
                $(this).parents('.input-group').remove();
            });
            if (user && (user.guests.length == 0 || user.guests.findIndex(item => guest === item.toLowerCase()) == -1)) {
                $.ajax({
                    method: 'POST',
                    url: `${domain}/api/add-guest`,
                    data: {
                        token: authToken,
                        email: guest,
                    },
                    success(data) {
                        if (data.status == 401) {
                            logout();
                        }
                    }
                });
            }
        }
        $('#guest-email').val('');
    });

    $('#datetimepicker').on("change.datetimepicker", ({date, oldDate}) => {
        $('#event-date').val(moment(date._d).format("YYYY-MM-DDTHH:mm:ssZ"));
        $('#selected-date').text(date._d.toString());
    });

    $('#send-inite').on('click', function() {
        if (limitation == 0) {
            $('#home-error').show();
            $('#main-error').html($('#home-error').html());
            return;
        }
        var app = $('[name=app]:checked').val();
        if (!app) {
            $('#app-error').text('Please select app');
            $('#main-error').html('Please select app');
            return;
        }
        var event_name = $('#event-name').val();
        if (event_name == '') {
            $('#event-name-error').text('Please input event name');
            $('#main-error').html('Please input event name');
            return;
        }
        var emails = $('#guest-list .form-control').map(function() {
            return $.trim($(this).text());
        }).get();
        if (emails.length == 0) {
            $('#guests-error').text('Please add emails');
            $('#main-error').html('Please add emails');
            return;
        }
        var event_date = $('#event-date').val();
        if (event_date == '') {
            $('#event-date-error').text('Please select date & time');
            return;
        }
        if (authToken) {
            createEvent({
                app: app,
                event_name: event_name,
                guests: emails,
                event_date: event_date,
            });
        } else {
            errorHandle();
        }
    });
    
    $('#successModal').on('hide.bs.modal', function () {
        errorHandle(1, true);
    });
});

function logout() {
    chrome.storage.local.set({'pigeon': null});
    setTimeout(gotoPage, delay, 'login');
}

function gotoPage(page) {
    $('.container').hide();
    $('#' + page + '-page').show();
    $('#loading').hide();
}