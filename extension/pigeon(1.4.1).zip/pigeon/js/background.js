var words = [], selected_value, links;
/* Event */
chrome.runtime.onMessage.addListener((request, sender, response) => {
    if (request.method == 'loaded_page') {
        if (sender.tab) {
            chrome.tabs.sendMessage(sender.tab.id, {
                method: 'word_list',
                words: words,
            });
        }
    } else if (request.method == 'show_menu') {
        chrome.contextMenus.update('pigeon-invite', {
            visible: true,
        });
        links = {};
        chrome.cookies.get({url: "https://www.linkedin.com/", name: "JSESSIONID"}, function (cookie) {
            var token, href;
            token = cookie.value.replace(/"/g, '');
            if (token != '') {
                request.links.forEach(function (link) {
                    if (!links[link]) {
                        href = link.replace('/in/', '/voyager/api/identity/profiles/') + 'profileContactInfo';
                        $.ajax({
                            url: href,
                            method: 'GET',
                            headers: {
                                "accept": "application/vnd.linkedin.normalized+json+2.1",
                                "csrf-token": token,
                                "x-li-lang": "en_US",
                                "x-restLi-protocol-version": "2.0.0",
                            },
                            success: function(data) {
                                links[link] = data.data.emailAddress;
                            }
                        });
                    }
                });
            }
        });
    } else if (request.method == 'hide_menu') {
        chrome.contextMenus.update('pigeon-invite', {
            visible: false,
        });
    } else if (request.method == 'contextmenu') {
        selected_value = {
            value: request.value,
            selected_links: request.links,
            links: links,
        }
    } else if (request.method == 'get_selected_value') {
        if (sender.tab) {
            chrome.tabs.sendMessage(sender.tab.id, {
                method: 'selected_value',
                value: selected_value,
            });
        }
    } else if (request.method == 'goto_page') {
        openPage(request.page);
    } else if (request.method == 'close_popup') {
        if (sender.tab) {
            chrome.tabs.sendMessage(sender.tab.id, {
                method: 'close_popup',
            });
        }
    }
});

chrome.contextMenus.onClicked.addListener(function (info, tab) {
    if (info.menuItemId === 'pigeon-invite') {
        chrome.tabs.sendMessage(tab.id, {
            method: 'open_popup',
        });
    }
});

chrome.runtime.onStartup.addListener(function() {
    installContextMenu();
});

chrome.runtime.onInstalled.addListener(function (details) {
    installContextMenu();
    chrome.tabs.query({url: 'https://www.linkedin.com/*'}, function(tabs) {
        tabs.forEach(function(tab) {
            chrome.tabs.reload(tab.id);
        });
    });
    chrome.tabs.create({ url: domain });
});
/* End Event */

function installContextMenu() {
    chrome.contextMenus.create({
        id: 'pigeon-invite',
        title: 'Pigeon Invite',
        visible: false,
        contexts: ['all'],
        documentUrlPatterns: ['https://www.linkedin.com/*'],
    });
}

function openPage(page) {
    chrome.tabs.create({ url: domain + page });
}

function getWords() {
    $.ajax({
        url: `${domain}/api/words`,
        method: 'GET',
        success: function(data) {
            words = data;
        },
        error: function(data) {
        }
    });
}

getWords();

setInterval(getWords, 5000);