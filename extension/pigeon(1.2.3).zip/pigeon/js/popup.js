var delay = 2000;

function setData(data) {
    for (key in data.result) {
        $('#' + key).text(data.result[key]);
    }
}

function errorHandle() {
    $('#error').text('Cannot connect to server');
    setTimeout(function() {
        window.close();
    }, 1000);
}