const domain = 'http://localhost:10000';
//const domain = 'https://joinpigeon.com';

const CLIENT_ID = '97803995479-0epuvc2735gllpi9hnp1k3pocb0le73t.apps.googleusercontent.com';
const CLIENT_SECRET = '6tkBTQUnoNx4V9GeJfp2cBxy';
const REDIRECT_URL = 'https://adlljmlbangmeenndganepfkilcdihnm.chromiumapp.org/';