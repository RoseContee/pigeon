var zoom_link = document.getElementById('zoom_link').value;
chrome.runtime.sendMessage({
    method: 'zoom_link',
    zoom_link: zoom_link,
});