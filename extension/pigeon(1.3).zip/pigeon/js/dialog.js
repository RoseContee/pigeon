var selected_value, limitation, user, delay = 0;
chrome.runtime.sendMessage({
    method: 'get_selected_value',
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.method == 'selected_value') {
        selected_value = request.value;
    } else if (request.method == 'zoom_link') {
        user.apps.zoom_link = request.zoom_link;
        $('#loading').hide();
    }
});

$(function () {
    $.ajax({
        method: 'GET',
        url: domain + '/api/apps',
        success(data) {
            data.forEach(function(app) {
                $('#apps').append(getAppTemplate(app));
            });

            $('.apps').on('click', function(e) {
                var app = $(this).data('name');
                $('#app-selected').text('(' + app + ' selected)');
                if (e.target.value == 2 && !user.apps.zoom_link) {
                    $('#loading').show();
                    zoomLogin();
                }
            });
        },
        error(data) {
        }
    });

    $('#event-date').val(new Date().toISOString());
    $('#selected-date').text(new Date().toGMTString());

    $('#datetimepicker').datetimepicker({
        inline: true,
        sideBySide: true,
        minDate: new Date(),
    });
});

function setData(data) {
    user = data.result.user;
    $('#guest-email').autocomplete({
        source: user.guests,
    });
    if (user.email) {
        userEmail = user.email;
    }
    if (selected_value.value && selected_value.value.includes('@')) {
        $('#guest-email').val(selected_value.value);
        $('#add-guest').click();
    }
    var email;
    selected_value.selected_links.forEach(function (href) {
        email = selected_value.links[href];
        if (email) {
            $('#guest-email').val(email);
            $('#add-guest').click();
        }
    });
    limitation = data.result.current;
    if (limitation == 0) {
        $('#home-error').show();
        return;
    }
}

function errorHandle(hide_error, instant) {
    if (!hide_error) $('#main-error').text('Cannot send invite at this time');
    setTimeout(function() {
        chrome.runtime.sendMessage({
            method: 'close_popup',
        });
    }, instant ? 0 : 1000);
}

function zoomLogin() {
    chrome.runtime.sendMessage({
        method: 'goto_page',
        page: '/auth/zoom',
        type: 'zoom',
    });
}

function requestId(length) {
    var result           = '';
    var characters       = 'abcdefghijklmnopqrstuvwxyz0123456789';
    var charactersLength = characters.length;
    for ( var i = 0; i < length; i++ ) {
       result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
 }

function getAppTemplate(app) {
    return `<div class="col-6 btn-group-toggle mt-1">
                <label class="btn p-1 text-center apps" data-name="${app.name}">
                    <img src="${app.image}" class="app-image">
                    <input type="radio" name="app" value="${app.id}">
                </label>
            </div>`;
}

function guestTemplate(email) {
    return `<div class="col-12 input-group mb-1">
                <div class="form-control pl-2 p-0 border-0">${email}</div>
                <div class="input-group-append">
                <button class="btn btn-outline-danger img-circle p-1 remove-guest"><i class="fa fa-minus"></i></button>
                </div>
            </div>`;
}