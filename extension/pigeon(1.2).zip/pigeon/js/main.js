var isMainTop = true, words = [];
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.method == 'word_list') {
        words = request.words;
    } else if (request.method == 'open_popup') {
        openEventDialog(request);
    } else if (request.method == 'close_popup') {
        document.querySelector('#pigeon-invite-diaglog #dialog-close').click();
    }
});

chrome.runtime.sendMessage({
    method: 'loaded_page',
});

setInterval(enjection, 1000);

function enjection() {
    removeEventHandler();
    var msg, target, modified, emailsArray;
    var messages = document.querySelectorAll('.msg-s-event-listitem__body');
    var mailFormat = /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*/g;
    messages.forEach(function(message) {
        msg = message.innerText;
        modified = false;
        words.forEach(function(word) {
            target = "<a class=\"contextmenu\">" + word + "</a>";
            msg = msg.replace(new RegExp(target, "gi"), word);
            msg = msg.replace(new RegExp("\\b" + word + "\\b", "gi"), target);
            if (msg.search(new RegExp("\\b" + word + "\\b", "gi")) > -1) {
                modified = true;
            }
        });
        if (emailsArray = msg.match(mailFormat)) {
            emailsArray.forEach(function(email) {
                target = "<a class=\"contextmenu\">" + email + "</a>";
                //msg = msg.replaceAll(target, email);
                msg = msg.replaceAll(email, target);
            });
            modified = true;
        }
        if (modified) message.innerHTML = msg;
    });
    addEventHandler();
}

function addEventHandler() {
    var menus = document.querySelectorAll('.contextmenu');
    menus.forEach(function(menu) {
        menu.addEventListener('mouseover', showMenu);
        menu.addEventListener('mouseout', hideMenu);
        menu.addEventListener('contextmenu', handleContext);
    });
}

function removeEventHandler() {
    var menus = document.querySelectorAll('.contextmenu');
    menus.forEach(function(menu) {
        menu.removeEventListener('mouseover', showMenu);
        menu.removeEventListener('mouseout', hideMenu);
        menu.removeEventListener('contextmenu', handleContext);
    });
}

function showMenu(e) {
    var links = getLinks(e);
    chrome.runtime.sendMessage({
        method: 'show_menu',
        links: links,
    });
}

function hideMenu() {
    chrome.runtime.sendMessage({
        method: 'hide_menu',
    });
}

function handleContext(e) {
    var links = getLinks(e);
    chrome.runtime.sendMessage({
        method: 'contextmenu',
        value: e.target.innerText,
        links: links,
    });
}

function getLinks(e) {
    var that = e.target, links = [], href;
    while(that && !that.classList.contains('msg-s-message-list')) {
        that = that.parentNode;
    }
    if (that) {
        that = document.querySelectorAll('#' + that.id + ' .msg-s-event-listitem__link');
        that.forEach(function(item) {
            href = item.href;
            if (!links.includes(href)) links.push(href);
        });
    }
    return links;
}

function openEventDialog(request) {
    var dialog = document.createElement('div');
    dialog.id = 'pigeon-invite-diaglog';
    dialog.innerHTML = dialogHtml;
    document.body.appendChild(dialog);
    document.querySelector('#pigeon-invite-diaglog #dialog-close').addEventListener('click', function() {
        document.getElementById("pigeon-invite-diaglog").remove();
    });
}

var dialogHtml = `<div class="artdeco-modal-overlay artdeco-modal-overlay--layer-default artdeco-modal-overlay--is-top-layer ember-view">
    <div class="artdeco-modal artdeco-modal--layer-default share-box-v2__modal">
        <button id="dialog-close" class="artdeco-modal__dismiss artdeco-button artdeco-button--circle artdeco-button--muted artdeco-button--2 artdeco-button--tertiary ember-view">
            <li-icon class="artdeco-button__icon">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" data-supported-dps="24x24"
                    fill="currentColor" width="24" height="24" focusable="false">
                    <path d="M20 5.32L13.32 12 20 18.68 18.66 20 12 13.33 5.34 20 4 18.68 10.68 12 4 5.32 5.32 4 12 10.69 18.68 4z"></path>
                </svg>
            </li-icon>
        </button>
        <div class="artdeco-modal__header ember-view">
            <h2>
                <img src="${chrome.extension.getURL('img/logo.png')}" class="logo-img" alt="Logo" />
                <b class="ml-2 logo-text">Pigeon Invite</b>
            </h2>
        </div>
        <div class="artdeco-modal__content share-box-v2__modal-content ember-view">
            <iframe id="dialog-content" src="${chrome.extension.getURL('html/dialog.html')}" width="100%" height="100%"></iframe>
        </div>
    </div>
</div>`;