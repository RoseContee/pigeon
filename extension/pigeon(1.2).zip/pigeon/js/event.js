var authToken = undefined;
$(function() {
    chrome.storage.local.get('pigeon', function (item) {
        if (item.pigeon && item.pigeon.google_refresh_token) {
            $.ajax({
                method: 'POST',
                url: 'https://oauth2.googleapis.com/token',
                data: {
                    client_id: CLIENT_ID,
                    client_secret: CLIENT_SECRET,
                    refresh_token: item.pigeon.google_refresh_token,
                    grant_type: 'refresh_token',
                },
                success(data) {
                    authToken = data.access_token;
                    $.ajax({
                        method: 'GET',
                        url: 'https://www.googleapis.com/oauth2/v1/userinfo',
                        data: {
                            access_token: authToken,
                        },
                        success(data) {
                            $.ajax({
                                method: 'POST',
                                url: domain + '/api/get-user-info',
                                data: {
                                    email: data.email,
                                    access_token: authToken,
                                },
                                success(data) {
                                    if (data.status == 200) {
                                        setData(data);
                                        setTimeout(gotoPage, delay, 'home');
                                    } else {
                                        logout();
                                    }
                                },
                                error(data) {
                                    errorHandle();
                                }
                            });
                        },
                        error(data) {
                            logout();
                        }
                    });
                },
                error(data) {
                    logout();
                }
            });
        } else {
            setTimeout(gotoPage, delay, 'login');
        }
    });

    $('input').on('keypress', function() {
        $('.errors').text('');
    });

    $('#google-login').on('click', function() {
        $('.login').hide(); $('#loading').show();
        $.ajax({
            method: 'GET',
            url: domain + '/api/get-token',
            success(data) {
                if (data.status == 200) {
                    const token = data.result;
                    chrome.identity.launchWebAuthFlow({
                        url: get_oauth_url(token),
                        interactive: true,
                    }, function(redirect_url) {
                        if (chrome.runtime.lastError) {
                            $('#error').text(chrome.runtime.lastError.message);
                            $('.login').show(); $('#loading').hide();
                            return;
                        }
                        redirect_url = new URL(redirect_url);
                        if (token != redirect_url.searchParams.get('state')) {
                            $('#error').text('Invalid state parameter');
                            $('.login').show(); $('#loading').hide();
                            return;
                        }
                        const code = redirect_url.searchParams.get('code');
                        $.ajax({
                            method: 'POST',
                            url: 'https://oauth2.googleapis.com/token',
                            data: {
                                code: code,
                                client_id: CLIENT_ID,
                                client_secret: CLIENT_SECRET,
                                redirect_uri: REDIRECT_URL,
                                grant_type: 'authorization_code',
                            },
                            success(data) {
                                const refresh_token = data.refresh_token;
                                authToken = data.access_token;
                                $.ajax({
                                    method: 'GET',
                                    url: 'https://oauth2.googleapis.com/tokeninfo',
                                    data: {
                                        id_token: data.id_token,
                                    },
                                    success(data) {
                                        $.ajax({
                                            method: 'POST',
                                            url: domain + '/api/auth-google',
                                            data: {
                                                token: token,
                                                access_token: authToken,
                                                email: data.email,
                                                name: data.name,
                                                avatar: data.picture,
                                                google_id: data.sub,
                                            },
                                            success(data) {
                                                if (data.status == 200) {
                                                    setData(data);
                                                    gotoPage('home');
                                                    chrome.storage.local.get('pigeon', function(item) {
                                                        if (!item.pigeon) item.pigeon = {};
                                                        item.pigeon.google_refresh_token = refresh_token;
                                                        chrome.storage.local.set({'pigeon': item.pigeon});
                                                    });
                                                } else {
                                                    $('#error').text(data.result.error);
                                                    $('.login').show(); $('#loading').hide();
                                                }
                                            },
                                            error(data) {
                                                errorHandle();
                                            }
                                        });
                                    },
                                    error(data) {
                                        errorHandle();
                                    }
                                });
                            },
                            error(data) {
                                errorHandle();
                            }
                        })
                    });
                }
            },
            error(data) {
                errorHandle();
            }
        });
    });
    
    $('#logout').on('click', logout);

    $('#goHome').on('click', function() {
        chrome.runtime.sendMessage({
            method: 'goto_homepage',
        });
    });

    $('#add-guest').on('click', function() {
        var guest = $('#guest-email').val().trim();
        if (guest == '') return;
        var mailFormat = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
        if (!guest.match(mailFormat)) {
            $('#guest-email-error').text('please input valid email');
            return;
        }
        var exist = false;
        $('#guest-list .form-control').each(function() {
            if ($(this).text().trim().toLowerCase() == guest.toLowerCase()) exist = true;
        });
        if (!exist) {
            $('#guest-list').append(guestTemplate(guest));
            $('.remove-guest').off('click').on('click', function() {
                $(this).parents('.input-group').remove();
            });
            if (user.guests.length == 0 ||
                user.guests.findIndex(item => guest.toLowerCase() === item.toLowerCase()) == -1) {
                $.ajax({
                    method: 'POST',
                    url: domain + '/api/add-guest',
                    data: {
                        token: authToken,
                        email: guest,
                    },
                    success(data) {
                        if (data.status == 401) {
                            logout();
                        }
                    }
                });
            }
        }
        $('#guest-email').val('');
    });

    $('#datetimepicker').on("change.datetimepicker", ({date, oldDate}) => {
        $('#event-date').val(moment(date._d).format("YYYY-MM-DDTHH:mm:ssZ"));
        $('#selected-date').text(date._d.toString());
    });

    $('#send-inite').on('click', function() {
        if (limitation == 0) {
            $('#home-error').show();
            $('#main-error').html($('#home-error').html());
            return;
        }
        var app = $('[name=app]:checked').val();
        if (!app) {
            $('#app-error').text('Please select app');
            $('#main-error').html('Please select app');
            return;
        }
        var attr = {}, i, attr_name = 'app_link_' + app;
        for (i = 1; i < (app == 2 ? 3 : 2); i++) {
            if (i == 2) {
                attr_name = 'app_passcode_' + app;
            }
            if (!user.app[attr_name]) {
                attr[attr_name] = $('#' + attr_name).val();
                if (attr[attr_name] == '') {
                    $('#' + attr_name + '-error').text('Please input value');
                    $('#main-error').html('Please input app data');
                    return;
                }
            }
        }
        var event_name = $('#event-name').val();
        if (event_name == '') {
            $('#event-name-error').text('Please input event name');
            $('#main-error').html('Please input event name');
            return;
        }
        var emails = $('#guest-list .form-control').map(function() {
            return $.trim($(this).text());
        }).get();
        if (emails.length == 0) {
            $('#guests-error').text('Please add emails');
            $('#main-error').html('Please add emails');
            return;
        }
        var event_date = $('#event-date').val();
        if (event_date == '') {
            $('#event-date-error').text('Please select date & time');
            return;
        }
        if (authToken) {
            createEvent({
                app: app,
                attr: attr,
                event_name: event_name,
                guests: emails,
                event_date: event_date,
            });
        } else {
            errorHandle();
        }
    });
});

function get_oauth_url(state) {
    return `https://accounts.google.com/o/oauth2/v2/auth?client_id=${encodeURIComponent(CLIENT_ID)}
&response_type=code
&redirect_uri=${encodeURIComponent(REDIRECT_URL)}
&state=${encodeURIComponent(state)}
&scope=${encodeURIComponent('openid profile email https://www.googleapis.com/auth/calendar')}
&prompt=consent
&nonce=${encodeURIComponent(Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15))}
&access_type=offline`;
}

function logout() {
    chrome.storage.local.set({'pigeon': null});
    setTimeout(gotoPage, delay, 'login');
}

function gotoPage(page) {
    $('.container').hide();
    $('#' + page + '-page').show();
}

function createEvent(request) {
    $.ajax({
        method: 'GET',
        url: 'https://www.googleapis.com/calendar/v3/users/me/calendarList',
        headers: {
            'Authorization': 'Bearer ' + authToken
        },
        success(data) {
            data.items.forEach(function(item) {
                if (item.accessRole == 'owner') {
                    var tz = Intl.DateTimeFormat().resolvedOptions().timeZone, attendees = [], app_link, app_passcode;
                    request.guests.forEach(function(email) {
                        attendees.push({'email': email});
                    });
                    app_link = (user.app['app_link_' + request.app] ? user.app['app_link_' + request.app] : (request.attr['app_link_' + request.app]));
                    app_passcode = (user.app['app_passcode_' + request.app] ? user.app['app_passcode_' + request.app] : (request.attr['app_passcode_' + request.app]));
                    var event_data = {
                        'summary': request.event_name,
                        'description': 'Hi,<br><br>' + user.name + ' is inviting you to attend ' + request.event_name + ' via Pigeon.<br><br>' +
                            'Here is the link to join the meeting - <a href="' + app_link + '">' + app_link + '</a><br>' +
                            'Passcode - ' + (!app_passcode ? 'No passcode needed' : app_passcode) + '<br><br>See you!<br>Pigeon Support',
                        'start': {
                            'dateTime': request.event_date
                        },
                        'end': {
                            'dateTime': request.event_date
                        },
                        'attendees': attendees,
                        'reminders': {
                            'useDefault': false,
                            'overrides': [
                                {'method': 'email', 'minutes': 30}
                            ]
                        },
                        'conferenceData': {
                            'entryPoints': [{
                                'entryPointType': "video",
                                'uri': app_link
                            }],
                            'conferenceSolution': {
                                'key': {
                                    'type': 'hangoutsMeet'
                                }
                            }
                        },
                    };
                    $.ajax({
                        method: 'POST',
                        url: 'https://www.googleapis.com/calendar/v3/calendars/'+item.id+'/events?sendUpdates=all&conferenceDataVersion=1',
                        headers: {
                            'Authorization': 'Bearer ' + authToken
                        },
                        dataType : 'json',
                        data: JSON.stringify(event_data),
                        success(data) {
                            if (data.status == 'confirmed') {
                                $.ajax({
                                    method: 'POST',
                                    url: domain + '/api/create-event',
                                    data: {
                                        token: authToken,
                                        app: request.app,
                                        attr: request.attr,
                                        event_name: request.event_name,
                                        host_name: item.id,
                                        guests: request.guests,
                                        event_date: moment(request.event_date).format("YYYY-MM-DDTHH:mm:ss"),
                                        timezone: tz,
                                    },
                                    success(data) {
                                        if (data.status == 200) {
                                            $('#main-error').removeClass('text-danger')
                                                .addClass('text-success').text('Event has been created successfully');
                                            errorHandle(1);
                                        } else if (data.status == 403) {
                                            for (key in data.message) {
                                                $('#' + key + '-error').text(data.message[key]);
                                            }
                                        } else {
                                            logout();
                                        }
                                    },
                                    error(data) {
                                        errorHandle();
                                    }
                                });
                            }
                        },
                        error(data) {
                            errorHandle();
                        }
                    });
                    return;
                }
            });
        },
        error(data) {
            errorHandle();
        }
    });
}