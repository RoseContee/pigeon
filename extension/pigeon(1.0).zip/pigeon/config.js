var domain = 'http://localhost:10000';
//var domain = 'https://joinpigeon.com';