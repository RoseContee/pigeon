var token;
$(function() {
    chrome.storage.local.get('pigeon', function (item) {
        if (item.pigeon && item.pigeon.token) {
            $.ajax({
                method: 'POST',
                url: domain + '/api/get-user-info',
                data: {
                    token: item.pigeon.token,
                },
                success(data) {
                    if (data.status == 200) {
                        token = item.pigeon.token;
                        setData(data);
                        setTimeout(gotoPage, delay, 'home');
                    } else {
                        item.pigeon.token = null;
                        chrome.storage.local.set({'pigeon': item.pigeon});
                        setTimeout(gotoPage, delay, 'login');
                    }
                },
                error(data) {
                    errorHandle();
                }
            });
        } else {
            setTimeout(gotoPage, delay, 'login');
        }
    });

    $('input').on('keypress', function() {
        $('.errors').text('');
    });

    $('#login').on('click', function() {
        var email = $('#email').val();
        if (email == '') {
            $('#email-error').text('Please input email');
            return;
        }
        var password = $('#password').val();
        if (password == '') {
            $('#password-error').text('Please input password');
            return;
        }
        $.ajax({
            method: 'POST',
            url: domain + '/api/login',
            data: {
                email: email,
                password: password,
            },
            success(data) {
                if (data.status == 200) {
                    token = data.result.token;
                    setData(data);
                    gotoPage('home');
                    chrome.storage.local.get('pigeon', function(item) {
                        if (!item.pigeon) item.pigeon = {};
                        item.pigeon.token = data.result.token;
                        chrome.storage.local.set({'pigeon': item.pigeon});
                    });
                } else {
                    $('#error').text(data.result.error);
                    $('#email-error').text(data.result.email);
                    $('#password-error').text(data.result.password);
                }
            },
            error(data) {
                errorHandle();
            }
        });
    });

    $('#forgotPassword').on('click', function() {
        chrome.runtime.sendMessage({
            method: 'forgot_password',
        });
    });

    $('#signup').on('click', function() {
        chrome.runtime.sendMessage({
            method: 'signup',
        });
    });
    
    $('#logout').on('click', logout);

    $('#goHome').on('click', function() {
        chrome.runtime.sendMessage({
            method: 'goto_homepage',
        });
    });

    $('#add-guest').on('click', function() {
        var email = $('#guest-email').val().trim();
        if (email == '') return;
        var mailFormat = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
        if (!email.match(mailFormat)) {
            $('#guest-email-error').text('please input valid email');
            return;
        }
        var exist = false;
        $('#guest-list .form-control').each(function() {
            if ($(this).text().trim().toLowerCase() == email.toLowerCase()) exist = true;
        });
        if (!exist) {
            $('#guest-list').append(guestTemplate(email));
            $('.remove-guest').off('click').on('click', function() {
                $(this).parents('.input-group').remove();
            });
            if (user.guests.length == 0 ||
                user.guests.findIndex(item => email.toLowerCase() === item.toLowerCase()) == -1) {
                $.ajax({
                    method: 'POST',
                    url: domain + '/api/add-guest',
                    data: {
                        token: token,
                        email: email,
                    },
                    success(data) {
                        if (data.status == 401) {
                            logout();
                        }
                    }
                });
            }
        }
        $('#guest-email').val('');
    });

    $('#datetimepicker').on("change.datetimepicker", ({date, oldDate}) => {
        $('#event-date').val(moment(date._d).format("YYYY-MM-DDTHH:mm:ssZ"));
        $('#selected-date').text(date._d.toString());
    });

    $('#send-inite').on('click', function() {
        if (limitation == 0) {
            $('#home-error').show();
            $('#main-error').html($('#home-error').html());
            return;
        }
        var app = $('[name=app]:checked').val();
        if (!app) {
            $('#app-error').text('Please select app');
            $('#main-error').html('Please select app');
            return;
        }
        var attr = {}, i, attr_name = 'app_link_' + app;
        for (i = 1; i < (app == 2 ? 3 : 2); i++) {
            if (i == 2) {
                attr_name = 'app_passcode_' + app;
            }
            if (!user.app[attr_name]) {
                attr[attr_name] = $('#' + attr_name).val();
                if (attr[attr_name] == '') {
                    $('#' + attr_name + '-error').text('Please input value');
                    $('#main-error').html('Please input app data');
                    return;
                }
            }
        }
        var event_name = $('#event-name').val();
        if (event_name == '') {
            $('#event-name-error').text('Please input event name');
            $('#main-error').html('Please input event name');
            return;
        }
        var emails = $('#guest-list .form-control').map(function() {
            return $.trim($(this).text());
        }).get();
        if (emails.length == 0) {
            $('#guests-error').text('Please add emails');
            $('#main-error').html('Please add emails');
            return;
        }
        var event_date = $('#event-date').val();
        if (event_date == '') {
            $('#event-date-error').text('Please select date & time');
            return;
        }
        if (authToken) {
            createEvent({
                app: app,
                attr: attr,
                event_name: event_name,
                guests: emails,
                event_date: event_date,
            });
        } else {
            errorHandle();
        }
    });
});

function logout() {
    chrome.storage.local.get('pigeon', function(item) {
        item.pigeon.token = null;
        chrome.storage.local.set({'pigeon': item.pigeon});
    });
    gotoPage('login');
}

function gotoPage(page) {
    $('.container').hide();
    $('#' + page + '-page').show();
}

function createEvent(request) {
    $.ajax({
        method: 'GET',
        url: 'https://www.googleapis.com/calendar/v3/users/me/calendarList',
        headers: {
            'Authorization': 'Bearer ' + authToken
        },
        success(data) {
            data.items.forEach(function(item) {
                if (item.accessRole == 'owner') {
                    var tz = Intl.DateTimeFormat().resolvedOptions().timeZone, attendees = [], app_link, app_passcode;
                    request.guests.forEach(function(item) {
                        attendees.push({'email': item});
                    });
                    app_link = (user.app['app_link_' + request.app] ? user.app['app_link_' + request.app] : (request.attr['app_link_' + request.app]));
                    app_passcode = (user.app['app_passcode_' + request.app] ? user.app['app_passcode_' + request.app] : (request.attr['app_passcode_' + request.app]));
                    var event_data = {
                        'summary': request.event_name,
                        'description': 'Hi,<br><br>' + user.name + ' is inviting you to attend ' + request.event_name + ' via Pigeon.<br><br>' +
                            'Here is the link to join the meeting - <a href="' + app_link + '">' + app_link + '</a><br>' +
                            'Passcode - ' + (!app_passcode ? 'No passcode needed' : app_passcode) + '<br><br>See you!<br>Pigeon Support',
                        'start': {
                            'dateTime': request.event_date
                        },
                        'end': {
                            'dateTime': request.event_date
                        },
                        'attendees': attendees,
                        'reminders': {
                            'useDefault': false,
                            'overrides': [
                                {'method': 'email', 'minutes': 30}
                            ]
                        },
                        'conferenceData': {
                            'entryPoints': [{
                                'entryPointType': "video",
                                'uri': app_link
                            }],
                            'conferenceSolution': {
                                'key': {
                                    'type': 'hangoutsMeet'
                                }
                            }
                        },
                    };
                    $.ajax({
                        method: 'POST',
                        url: 'https://www.googleapis.com/calendar/v3/calendars/'+item.id+'/events?sendUpdates=all&conferenceDataVersion=1',
                        headers: {
                            'Authorization': 'Bearer ' + authToken
                        },
                        dataType : 'json',
                        data: JSON.stringify(event_data),
                        success(data) {
                            if (data.status == 'confirmed') {
                                $.ajax({
                                    method: 'POST',
                                    url: domain + '/api/create-event',
                                    data: {
                                        token: token,
                                        app: request.app,
                                        attr: request.attr,
                                        event_name: request.event_name,
                                        host_name: item.id,
                                        guests: request.guests,
                                        event_date: moment(request.event_date).format("YYYY-MM-DDTHH:mm:ss"),
                                        timezone: tz,
                                    },
                                    success(data) {
                                        if (data.status == 200) {
                                            $('#main-error').removeClass('text-danger')
                                                .addClass('text-success').text('Event has been created successfully');
                                            errorHandle(1);
                                        } else if (data.status == 403) {
                                            for (key in data.message) {
                                                $('#' + key + '-error').text(data.message[key]);
                                            }
                                        } else {
                                            logout();
                                        }
                                    },
                                    error(data) {
                                        errorHandle();
                                    }
                                });
                            }
                        },
                        error(data) {
                            errorHandle();
                        }
                    });
                    return;
                }
            });
        },
        error(data) {
            errorHandle();
        }
    });
}