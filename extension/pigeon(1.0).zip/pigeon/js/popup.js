var delay = 2000;

function setData(data) {
    for (key in data.result) {
        $('#' + key).text(data.result[key]);
    }
}

function errorHandle() {
    window.close();
}