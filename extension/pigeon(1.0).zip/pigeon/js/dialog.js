var selected_value, limitation, user, authToken = undefined, delay = 0;
chrome.runtime.sendMessage({
    method: 'get_selected_value',
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.method == 'selected_value') {
        selected_value = request.value;
    }
});

$(function () {
    chrome.storage.local.get('pigeon', function (item) {
        $.ajax({
            method: 'GET',
            url: domain + '/api/apps',
            success(data) {
                data.forEach(function(app) {
                    $('#apps').append(getAppTemplate(app));
                });

                $('.apps').on('click', function() {
                    var app = $(this).text().trim();
                    $('#app-selected').text('(' + app + ' selected)');
                });

                $('[name=app]').on('change', function() {
                    var app = $('[name=app]:checked').val();
                    $('#app-attributes').html('');
                    if (!user.app['app_link_' + app]) {
                        $('#app-attributes').append(getAppAttributeTemplate('app_link_' + app, 'Link'));
                    }
                    if (app == 2 && !user.app['app_passcode_' + app]) {
                        $('#app-attributes').append(getAppAttributeTemplate('app_passcode_' + app, 'Passcode'));
                    }

                    $('.errors').text('');

                    $('input').off('keypress').on('keypress', function() {
                        $('.errors').text('');
                    });
                });
            },
            error(data) {
            }
        });
    });

    $('#event-date').val(new Date().toISOString());
    $('#selected-date').text(new Date().toGMTString());

    $('#datetimepicker').datetimepicker({
        inline: true,
        sideBySide: true,
    });
});

function setData(data) {
    user = data.result.user;
    $('#guest-email').autocomplete({
        source: user.guests,
    });
    if (user.email) {
        $('#guest-email').val(user.email);
        $('#add-guest').click();
    }
    if (selected_value.value && selected_value.value.includes('@')) {
        $('#guest-email').val(selected_value.value);
        $('#add-guest').click();
    }
    var email;
    selected_value.selected_links.forEach(function (href) {
        email = selected_value.links[href];
        if (email) {
            $('#guest-email').val(email);
            $('#add-guest').click();
        }
    });
    limitation = data.result.current;
    if (limitation == 0) {
        $('#home-error').show();
        return;
    }
    chrome.identity.getAuthToken({ 'interactive': true }, function(token) {
        authToken = token;
    });
}

function errorHandle(hide_error) {
    if (!hide_error) $('#main-error').text('Cannot send invite at this time');
    setTimeout(function() {
        chrome.runtime.sendMessage({
            method: 'close_popup',
        });
    }, 1000);
}

function getAppTemplate(app) {
    return '<div class="col-6 btn-group-toggle mt-1">\
                <label class="btn btn-dark p-1 apps">\
                    <input type="radio" name="app" value="' + app.id + '">' + app.name + '\
                </label>\
            </div>';
}

function getAppAttributeTemplate(attr, title) {
    return '<div class="col-12 mt-2">\
                <input type="text" id="' + attr + '" class="form-control" placeholder="Input ' + title + '">\
                <div id="' + attr + '-error" class="col-12 text-center small text-danger errors"></div>\
            </div>';
}

function guestTemplate(email) {
    return '<div class="col-12 input-group mb-1">\
                <div class="form-control pl-2 p-0 border-0">' + email + '</div>\
                <div class="input-group-append">\
                <button class="btn btn-outline-danger img-circle p-1 remove-guest"><i class="fa fa-minus"></i></button>\
                </div>\
            </div>';
}